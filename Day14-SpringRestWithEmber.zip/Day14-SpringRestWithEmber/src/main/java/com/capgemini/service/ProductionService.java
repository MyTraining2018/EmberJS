package com.capgemini.service;

import java.util.List;

import com.capgemini.pojo.Production;

public interface ProductionService {
	
	public List<Production> getAllProduction();

	public List<Production> findProduction(int productID);

	public void deleteProduction(int productId);

	public void updateAccount(Production prod);

	public void registerProduction(Production prod);
}
