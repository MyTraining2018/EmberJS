package com.capgemini.pojo;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ember_product")
public class Production {

	@Id
	@Embedded
	private ProductId productId;
	private String productName;
	private String dimensionName;
	private double boardsSum;
	private double boardFeetSum;
	private int nominalThickness;
	private int nominalWidth;
	private int nominalLength;
	
	public Production() {}

	public Production(ProductId productId, String productName, String dimensionName, double boardsSum,
			double boardFeetSum, int nominalThickness, int nominalWidth, int nominalLength) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.dimensionName = dimensionName;
		this.boardsSum = boardsSum;
		this.boardFeetSum = boardFeetSum;
		this.nominalThickness = nominalThickness;
		this.nominalWidth = nominalWidth;
		this.nominalLength = nominalLength;
	}

	@Override
	public String toString() {
		return "Production [productId=" + productId + ", productName=" + productName + ", dimensionName="
				+ dimensionName + ", boardsSum=" + boardsSum + ", boardFeetSum=" + boardFeetSum + ", nominalThickness="
				+ nominalThickness + ", nominalWidth=" + nominalWidth + ", nominalLength=" + nominalLength + "]";
	}

	public ProductId getProductId() {
		return productId;
	}

	public void setProductId(ProductId productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDimensionName() {
		return dimensionName;
	}

	public void setDimensionName(String dimensionName) {
		this.dimensionName = dimensionName;
	}

	public double getBoardsSum() {
		return boardsSum;
	}

	public void setBoardsSum(double boardsSum) {
		this.boardsSum = boardsSum;
	}

	public double getBoardFeetSum() {
		return boardFeetSum;
	}

	public void setBoardFeetSum(double boardFeetSum) {
		this.boardFeetSum = boardFeetSum;
	}

	public int getNominalThickness() {
		return nominalThickness;
	}

	public void setNominalThickness(int nominalThickness) {
		this.nominalThickness = nominalThickness;
	}

	public int getNominalWidth() {
		return nominalWidth;
	}

	public void setNominalWidth(int nominalWidth) {
		this.nominalWidth = nominalWidth;
	}

	public int getNominalLength() {
		return nominalLength;
	}

	public void setNominalLength(int nominalLength) {
		this.nominalLength = nominalLength;
	}
	
}
