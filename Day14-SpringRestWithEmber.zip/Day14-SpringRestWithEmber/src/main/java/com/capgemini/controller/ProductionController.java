package com.capgemini.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.pojo.Production;
import com.capgemini.service.ProductionService;


@RestController
public class ProductionController {
	
	@Autowired
	private ProductionService productionService;
	
	@GetMapping("/api/production")
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ResponseEntity<List<Production>> getAllProductions(HttpServletResponse response) {
		List<Production> productions = productionService.getAllProduction();
		
		if (productions == null) {
			return new ResponseEntity("Sorry, unable to retrieve objects!", HttpStatus.NOT_FOUND);
		}
		
		response.addHeader("Access-Control-Allow-Origin", "http://localhost:4200");
		
		return new ResponseEntity<>(productions, HttpStatus.OK);
	}
	
	@GetMapping("/api/production/{productID}")
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ResponseEntity<List<Production>> getProduction(@PathVariable("productID") int productID, HttpServletResponse response) {
		
		List<Production> productions = productionService.findProduction(productID);
		
		if (productions == null) {
			return new ResponseEntity("Sorry, account is not found!", HttpStatus.NOT_FOUND);
		}
		
		response.addHeader("Access-Control-Allow-Origin", "http://localhost:4200");
		
		return new ResponseEntity<>(productions, HttpStatus.OK);
	}
	
	@PostMapping("/api/production")
	public ResponseEntity<Production> createProduction(@RequestBody Production prod, HttpServletResponse response) {
		productionService.registerProduction(prod);
		
		response.addHeader("Access-Control-Allow-Origin", "http://localhost:4200");
		
		return new ResponseEntity<>(prod, HttpStatus.OK);
	}
	
	@DeleteMapping("/api/production/{productId}")
	public ResponseEntity<String> deleteProduction(@PathVariable("productId") int productId, HttpServletResponse response) {
		productionService.deleteProduction(productId);
		
		response.addHeader("Access-Control-Allow-Origin", "http://localhost:4200");
		
		return new ResponseEntity<>("Deleting Production "+productId+ "!", HttpStatus.OK);
	}
	
	@PutMapping("/api/production")
	public ResponseEntity<Production> updateProduction(@RequestBody Production prod, HttpServletResponse response) {
		productionService.updateAccount(prod);
		
		response.addHeader("Access-Control-Allow-Origin", "http://localhost:4200");
		
		return new ResponseEntity<>(prod, HttpStatus.OK);
	}
	
}
