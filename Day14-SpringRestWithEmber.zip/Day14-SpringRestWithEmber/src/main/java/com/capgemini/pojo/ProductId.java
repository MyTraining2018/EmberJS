package com.capgemini.pojo;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class ProductId implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private int ProductID;
	private int DimensionID;
	
	public ProductId() {}

	public ProductId(int productID, int dimensionID) {
		super();
		ProductID = productID;
		DimensionID = dimensionID;
	}

	@Override
	public String toString() {
		return "ProductId [ProductID=" + ProductID + ", DimensionID=" + DimensionID + "]";
	}

	public int getProductID() {
		return ProductID;
	}

	public void setProductID(int productID) {
		ProductID = productID;
	}

	public int getDimensionID() {
		return DimensionID;
	}

	public void setDimensionID(int dimensionID) {
		DimensionID = dimensionID;
	}
	
	

}
