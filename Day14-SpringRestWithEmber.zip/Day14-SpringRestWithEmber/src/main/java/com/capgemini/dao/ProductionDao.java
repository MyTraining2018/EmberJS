package com.capgemini.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.pojo.ProductId;
import com.capgemini.pojo.Production;

@Repository("productionDao")
public interface ProductionDao extends CrudRepository<Production, ProductId>{

	@Query("select p from Production p where p.productId.ProductID = :pId")
	public List<Production> findByUsingQuery(@Param("pId") int productId);
	
//	@Query(nativeQuery=true)
//	public void deleteByUsingQuery(@Param("pId") int productId);
	
	@Modifying
	@Query("delete from Production p where p.productId.ProductID = :pId")
	public void deleteByUsingQuery(@Param("pId") int productId);
}
