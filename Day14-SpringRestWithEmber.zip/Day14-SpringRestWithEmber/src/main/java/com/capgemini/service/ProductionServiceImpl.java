package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.dao.ProductionDao;
import com.capgemini.pojo.Production;

@Service("productionService")
@Transactional
public class ProductionServiceImpl implements ProductionService {
	
	@Autowired
	ProductionDao productionDao;
	
	@Override
	public List<Production> getAllProduction() {
		return (List<Production>) productionDao.findAll();
	}

	@Override
	public List<Production> findProduction(int productID) {
		return productionDao.findByUsingQuery(productID);
	}

	@Override
	public void deleteProduction(int productId) {
		productionDao.deleteByUsingQuery(productId);	
	}

	@Override
	public void updateAccount(Production prod) {
		Production product = productionDao.findOne(prod.getProductId());
		product.setBoardFeetSum(prod.getBoardFeetSum());
		product.setBoardsSum(prod.getBoardsSum());
		product.setDimensionName(prod.getDimensionName());
		product.setNominalLength(prod.getNominalLength());
		product.setNominalThickness(prod.getNominalThickness());
		product.setNominalWidth(prod.getNominalWidth());
		product.setProductName(prod.getProductName());
	}

	@Override
	public void registerProduction(Production prod) {
		productionDao.save(prod);
	}



}
